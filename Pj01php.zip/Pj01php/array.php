<?php

$nomes = array ('Adriano', 'Maria', 'Zeka', 'Julia');

$numeros = array (1,2, 3, 4, 5);

foreach($nomes as $nome)
{
    echo $nome."<br>"; 
}

foreach($numeros as $numero)
{
    echo $numero * 2;
}

?> 