<?php

for($x = 1; $x<= 10000; $x++)
{
    echo "<br>   ".$nome;
}


?>