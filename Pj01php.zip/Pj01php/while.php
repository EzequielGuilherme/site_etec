<?php

$sobre = 1;

while ($sobre <= 1000)
{
    echo "<br> zeka ".$sobre ;
    $sobre++;
}

?>